


#ifndef _courbe_h
#define _courbe_h

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include <string.h>

void DessinerGraphe(int nbrSerie);

#endif
